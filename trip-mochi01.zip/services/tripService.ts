import { db } from '../firebase';
import { 
  doc, 
  setDoc, 
  getDoc, 
  deleteDoc,
  updateDoc,
  collection,
  getDocs,
  onSnapshot, 
  arrayUnion, 
  arrayRemove,
  Timestamp,
  writeBatch
} from 'firebase/firestore';
import { PocketItem, Journal, ScheduleItem } from '../types';
import { compressBase64IfNeeded } from '../utils/imageService';
import { CURRENT_SCHEMA_VERSION } from '../src/shared/types/schema';
import { normalizeImagesList } from '../src/shared/utils/imageAdapter';

/**
 * Sorts schedule items reliably based on:
 * 1. Date (always chronological by date string)
 * 2. Item-level `order` property (numeric position on that date)
 * 3. Root trip document `scheduleOrder` (ordered array of item IDs)
 * 4. Fallback to `time` (chronological) and deterministic ID
 */
export const sortScheduleItems = (items: ScheduleItem[], scheduleOrder?: string[]): ScheduleItem[] => {
  if (!Array.isArray(items) || items.length <= 1) return items || [];

  const orderMap = new Map<string, number>();
  if (Array.isArray(scheduleOrder) && scheduleOrder.length > 0) {
    scheduleOrder.forEach((id, idx) => orderMap.set(String(id), idx));
  }

  return [...items].sort((a, b) => {
    // 1. Always sort by date first (chronological by date string)
    const dateA = a.date || '';
    const dateB = b.date || '';
    if (dateA !== dateB) {
      return dateA.localeCompare(dateB);
    }

    // 2. Within the same date: If both items have explicit numeric order, sort by order
    const hasOrderA = typeof a.order === 'number';
    const hasOrderB = typeof b.order === 'number';
    if (hasOrderA && hasOrderB && a.order !== b.order) {
      return a.order! - b.order!;
    }
    if (hasOrderA && !hasOrderB) return -1;
    if (!hasOrderA && hasOrderB) return 1;

    // 3. If explicit scheduleOrder exists from root doc, use it
    const hasMapA = orderMap.has(String(a.id));
    const hasMapB = orderMap.has(String(b.id));
    if (hasMapA && hasMapB && orderMap.get(String(a.id)) !== orderMap.get(String(b.id))) {
      return orderMap.get(String(a.id))! - orderMap.get(String(b.id))!;
    }
    if (hasMapA && !hasMapB) return -1;
    if (!hasMapA && hasMapB) return 1;

    // 4. Chronological by time
    const timeA = a.time || '';
    const timeB = b.time || '';
    if (timeA && timeB && timeA !== timeB) {
      return timeA.localeCompare(timeB);
    }
    if (timeA && !timeB) return -1;
    if (!timeA && timeB) return 1;

    // 5. Deterministic fallback by id
    return String(a.id).localeCompare(String(b.id));
  });
};

/**
 * Utility to recursively remove undefined properties from an object.
 * Firestore does not allow undefined values.
 */
const cleanData = (obj: any): any => {
  if (Array.isArray(obj)) {
    return obj.map(cleanData);
  } else if (obj !== null && typeof obj === 'object' && !(obj instanceof Timestamp)) {
    return Object.fromEntries(
      Object.entries(obj)
        .filter(([_, v]) => v !== undefined)
        .map(([k, v]) => [k, cleanData(v)])
    );
  }
  return obj;
};

/**
 * Sequential write queue to serialize outgoing Firestore writes.
 * Prevents overlapping concurrent writes from exceeding Firestore's HTTP/2 write stream
 * capacity ("Write stream exhausted maximum allowed queued writes").
 */
let writeQueue = Promise.resolve();
export const queueWrite = <T>(op: () => Promise<T>): Promise<T> => {
  const result = writeQueue.then(op, op);
  writeQueue = result.then(() => {}, () => {});
  return result;
};

/**
 * Generates a readable 6-digit trip code.
 * Excludes confusing characters like I, 1, O, 0.
 */
export const generateTripCode = (): string => {
  const chars = 'ABCDEFGHJKLMNPQRSTUVWXYZ23456789';
  let code = '';
  for (let i = 0; i < 6; i++) {
    code += chars.charAt(Math.floor(Math.random() * chars.length));
  }
  return code;
};

/**
 * Creates a new trip document with a unique 6-digit ID.
 * Performs collision check to ensure ID uniqueness.
 */
export const createTrip = async (name: string): Promise<string> => {
  try {
    let code = generateTripCode();
    let collision = true;
    let attempts = 0;

    // Basic collision check
    while (collision && attempts < 5) {
      const docRef = doc(db, 'trips', code);
      const snap = await getDoc(docRef);
      if (!snap.exists()) {
        collision = false;
      } else {
        code = generateTripCode();
        attempts++;
      }
    }

    const initialData = {
      id: code,
      name,
      createdAt: Timestamp.now(),
      tripDays: [{ date: new Date().toISOString().split('T')[0], location: '第一天' }],
      scheduleItems: [],
      members: [{ id: '1', name: '我', fruit: '🍎' }],
      flights: [],
      accommodations: [],
      carRentals: [],
      tickets: [],
      expenses: [],
      journals: [],
      planning: { todo: [], packing: [], wish: [], shopping: [] },
      currencies: [
        { code: 'JPY', rate: 0.21 }, 
        { code: 'USD', rate: 32.5 }, 
        { code: 'KRW', rate: 0.024 }
      ],
      pocketItems: []
    };

    const tripRef = doc(db, 'trips', code);
    await setDoc(tripRef, initialData);
    
    return code;
  } catch (error) {
    console.error("Failed to create trip:", error);
    throw new Error("建立行程失敗，請檢查網路連線。");
  }
};

/**
 * Duplicates an existing trip with a new code.
 */
export const duplicateTrip = async (originalTripId: string): Promise<string> => {
  try {
    const originalRef = doc(db, 'trips', originalTripId);
    const snap = await getDoc(originalRef);

    if (!snap.exists()) {
      throw new Error("找不到原始行程資料");
    }

    const data = snap.data();
    let newCode = generateTripCode();
    let collision = true;
    let attempts = 0;

    while (collision && attempts < 5) {
      const docRef = doc(db, 'trips', newCode);
      const s = await getDoc(docRef);
      if (!s.exists()) {
        collision = false;
      } else {
        newCode = generateTripCode();
        attempts++;
      }
    }

    const newData = {
      ...data,
      id: newCode,
      name: `${data.name} (副本)`,
      createdAt: Timestamp.now(),
      scheduleItems: [],
      pocketItems: [],
      journals: [],
    };

    const newTripRef = doc(db, 'trips', newCode);
    await setDoc(newTripRef, newData);

    // Also copy subcollection scheduleItems if any
    try {
      const scheduleCol = collection(db, 'trips', originalTripId, 'scheduleItems');
      const scheduleSnap = await getDocs(scheduleCol);
      for (const itemDoc of scheduleSnap.docs) {
        await setDoc(doc(db, 'trips', newCode, 'scheduleItems', itemDoc.id), itemDoc.data());
      }
    } catch (subErr) {
      console.warn("Failed to copy subcollection scheduleItems:", subErr);
    }

    // Also copy subcollection pocketItems if any
    try {
      const pocketCol = collection(db, 'trips', originalTripId, 'pocketItems');
      const pocketSnap = await getDocs(pocketCol);
      for (const pocketDoc of pocketSnap.docs) {
        await setDoc(doc(db, 'trips', newCode, 'pocketItems', pocketDoc.id), pocketDoc.data());
      }
    } catch (subErr) {
      console.warn("Failed to copy subcollection pocketItems:", subErr);
    }

    // Also copy subcollection journals if any
    try {
      const journalCol = collection(db, 'trips', originalTripId, 'journals');
      const journalSnap = await getDocs(journalCol);
      for (const journalDoc of journalSnap.docs) {
        await setDoc(doc(db, 'trips', newCode, 'journals', journalDoc.id), journalDoc.data());
      }
    } catch (subErr) {
      console.warn("Failed to copy subcollection journals:", subErr);
    }
    
    return newCode;
  } catch (error) {
    console.error("Duplicate trip failed", error);
    throw new Error("建立副本失敗");
  }
};

/**
 * Joins an existing trip by its 6-digit code.
 */
export const joinTripByCode = async (code: string): Promise<any> => {
  try {
    const cleanCode = code.trim().toUpperCase();
    if (!cleanCode) throw new Error("請輸入代碼");

    const tripRef = doc(db, 'trips', cleanCode);
    const scheduleCol = collection(db, 'trips', cleanCode, 'scheduleItems');
    const pocketCol = collection(db, 'trips', cleanCode, 'pocketItems');
    const journalCol = collection(db, 'trips', cleanCode, 'journals');

    // Run main document and all 3 subcollections in parallel for lightning-fast loading
    const [snap, scheduleSnap, pocketSnap, journalSnap] = await Promise.all([
      getDoc(tripRef),
      getDocs(scheduleCol).catch(e => { console.warn("Subcollection read fallback (schedule):", e); return null; }),
      getDocs(pocketCol).catch(e => { console.warn("Subcollection read fallback (pocket):", e); return null; }),
      getDocs(journalCol).catch(e => { console.warn("Subcollection read fallback (journal):", e); return null; })
    ]);

    if (!snap.exists()) {
      throw new Error("找不到此行程碼，請檢查是否輸入正確。");
    }

    const data = snap.data();

    // 1. Fetch schedule items from subcollection and merge
    const scheduleMap = new Map<string, ScheduleItem>();
    if (Array.isArray(data.scheduleItems)) {
      for (const item of data.scheduleItems) {
        if (item && item.id) scheduleMap.set(String(item.id), item);
      }
    }
    if (scheduleSnap) {
      for (const d of scheduleSnap.docs) {
        const item = d.data() as ScheduleItem;
        if (item && item.id) scheduleMap.set(String(item.id), item);
      }
    }
    const rawSchedule = Array.from(scheduleMap.values());
    data.scheduleItems = sortScheduleItems(rawSchedule, data.scheduleOrder);

    // 2. Fetch pocket items from subcollection and merge defensively
    const pocketMap = new Map<string, PocketItem>();
    if (Array.isArray(data.pocketItems)) {
      for (const item of data.pocketItems) {
        if (item && item.id) pocketMap.set(String(item.id), item);
      }
    }
    if (pocketSnap) {
      for (const d of pocketSnap.docs) {
        const item = d.data() as PocketItem;
        if (item && item.id) {
          const prevItem = pocketMap.get(String(item.id));
          if (prevItem) {
            // Defensively preserve notes, images, priceRange, etc. if subcollection doc was missing any field
            pocketMap.set(String(item.id), {
              ...prevItem,
              ...item,
              notes: item.notes || (item as any).note || prevItem.notes || (prevItem as any).note || '',
              images: (Array.isArray(item.images) && item.images.length > 0) ? item.images : (prevItem.images || []),
              location: item.location || (item as any).address || prevItem.location || (prevItem as any).address || '',
              url: item.url || (item as any).googleMapUrl || (item as any).link || prevItem.url || (prevItem as any).googleMapUrl || '',
              priceRange: item.priceRange || (item as any).price || prevItem.priceRange || (prevItem as any).price || '',
            });
          } else {
            pocketMap.set(String(item.id), item);
          }
        }
      }
    }
    const finalPocket = Array.from(pocketMap.values());
    finalPocket.sort((a, b) => (b.createdAt || 0) - (a.createdAt || 0));
    data.pocketItems = finalPocket;

    // 3. Fetch journals from subcollection and merge
    const journalMap = new Map<string, Journal>();
    if (Array.isArray(data.journals)) {
      for (const item of data.journals) {
        if (item && item.id) journalMap.set(String(item.id), item);
      }
    }
    if (journalSnap) {
      for (const d of journalSnap.docs) {
        const item = d.data() as Journal;
        if (item && item.id) journalMap.set(String(item.id), item);
      }
    }
    const finalJournals = Array.from(journalMap.values());
    finalJournals.sort((a, b) => (b.date || '').localeCompare(a.date || ''));
    data.journals = finalJournals;

    return data;
  } catch (error: any) {
    console.error("Failed to join trip:", error);
    throw error;
  }
};

/**
 * Saves a single schedule item into subcollection (prevents 1MB root doc limit)
 */
export const saveScheduleItem = async (tripId: string, item: ScheduleItem): Promise<void> => {
  if (!tripId || !item || !item.id) return;
  return queueWrite(async () => {
    try {
      // Proactive safety: Only re-compress if an image is abnormally giant (>380KB Base64) before saving
      if (Array.isArray(item.images) && item.images.length > 0) {
        const sanitizedImages: string[] = [];
        for (const img of item.images) {
          if (typeof img === 'string' && img.startsWith('data:image/') && img.length > 380000) {
            const compressed = await compressBase64IfNeeded(img, 1200, 320000);
            sanitizedImages.push(compressed);
          } else {
            sanitizedImages.push(img);
          }
        }
        item = { ...item, images: sanitizedImages };
      }

      // Schema V2 compliance & image reference normalization
      item = {
        ...item,
        schemaVersion: CURRENT_SCHEMA_VERSION,
        imageReferences: normalizeImagesList(item.images, (item as any).image, (item as any).photos),
      };

      let cleaned = cleanData(item);

      // Check total estimated payload size (scheduleItem subcollection doc limit is 1,048,576 bytes)
      const payloadSize = JSON.stringify(cleaned).length;
      if (payloadSize > 880000 && Array.isArray(cleaned.images)) {
        cleaned.images = await Promise.all(
          cleaned.images.map((img: string) => compressBase64IfNeeded(img, 1000, 200000))
        );
      }

      const itemRef = doc(db, 'trips', tripId, 'scheduleItems', String(item.id));
      const tripRef = doc(db, 'trips', tripId);

      const batch = writeBatch(db);
      batch.set(itemRef, cleaned);
      batch.set(tripRef, {
        scheduleOrder: arrayUnion(String(item.id))
      }, { merge: true });

      try {
        await batch.commit();
      } catch (setErr: any) {
        // Automatic recovery if Firestore throws maximum document size exceeded error
        if (setErr?.message?.includes('size') || setErr?.message?.includes('1,048,576') || setErr?.code === 'resource-exhausted') {
          console.warn("Firestore size exceeded, applying emergency image compression...", setErr);
          if (Array.isArray(cleaned.images)) {
            cleaned.images = await Promise.all(
              cleaned.images.map((img: string) => compressBase64IfNeeded(img, 900, 140000))
            );
            const retryBatch = writeBatch(db);
            retryBatch.set(itemRef, cleaned);
            retryBatch.set(tripRef, {
              scheduleOrder: arrayUnion(String(item.id))
            }, { merge: true });
            await retryBatch.commit();
          } else {
            throw setErr;
          }
        } else {
          throw setErr;
        }
      }
    } catch (err) {
      console.error("Failed to save schedule item to subcollection:", err);
      throw err;
    }
  });
};

/**
 * Deletes a single schedule item from subcollection
 */
export const deleteScheduleItem = async (tripId: string, itemId: string): Promise<void> => {
  if (!tripId || !itemId) return;
  return queueWrite(async () => {
    try {
      const itemRef = doc(db, 'trips', tripId, 'scheduleItems', String(itemId));
      const tripRef = doc(db, 'trips', tripId);

      const batch = writeBatch(db);
      batch.delete(itemRef);
      batch.set(tripRef, {
        scheduleOrder: arrayRemove(String(itemId))
      }, { merge: true });

      await batch.commit();
    } catch (err) {
      console.error("Failed to delete schedule item from subcollection:", err);
      throw err;
    }
  });
};

/**
 * Saves a single pocket item into subcollection (prevents 1MB root doc limit)
 */
export const savePocketItem = async (tripId: string, item: PocketItem): Promise<void> => {
  if (!tripId || !item || !item.id) return;
  return queueWrite(async () => {
    try {
      // 1. Proactive image array and single image safety check (>380KB)
      if (item.image && typeof item.image === 'string' && item.image.startsWith('data:image/') && item.image.length > 380000) {
        item = { ...item, image: await compressBase64IfNeeded(item.image, 1200, 320000) };
      }

      if (Array.isArray(item.images) && item.images.length > 0) {
        const sanitizedImages: string[] = [];
        for (const img of item.images) {
          if (typeof img === 'string' && img.startsWith('data:image/') && img.length > 380000) {
            const compressed = await compressBase64IfNeeded(img, 1200, 320000);
            sanitizedImages.push(compressed);
          } else {
            sanitizedImages.push(img);
          }
        }
        item = { ...item, images: sanitizedImages };
      }

      // Schema V2 compliance & image reference normalization
      item = {
        ...item,
        schemaVersion: CURRENT_SCHEMA_VERSION,
        imageReferences: normalizeImagesList(item.images, (item as any).image, (item as any).photos),
      };

      let cleaned = cleanData(item);

      // 2. Multi-image document safety: If total size > 880KB, compress images further to prevent 1MB Firestore doc limit
      const payloadSize = JSON.stringify(cleaned).length;
      if (payloadSize > 880000 && Array.isArray(cleaned.images)) {
        cleaned.images = await Promise.all(
          cleaned.images.map((img: string) => compressBase64IfNeeded(img, 1000, 200000))
        );
      }

      const itemRef = doc(db, 'trips', tripId, 'pocketItems', String(item.id));
      
      try {
        await setDoc(itemRef, cleaned);
      } catch (setErr: any) {
        if (setErr?.message?.includes('size') || setErr?.message?.includes('1,048,576') || setErr?.code === 'resource-exhausted') {
          console.warn("Firestore pocketItem size exceeded, applying emergency compression...", setErr);
          if (Array.isArray(cleaned.images)) {
            cleaned.images = await Promise.all(
              cleaned.images.map((img: string) => compressBase64IfNeeded(img, 900, 140000))
            );
            await setDoc(itemRef, cleaned);
          } else {
            throw setErr;
          }
        } else {
          throw setErr;
        }
      }
    } catch (err) {
      console.error("Failed to save pocket item to subcollection:", err);
      throw err;
    }
  });
};

/**
 * Deletes a single pocket item from subcollection
 */
export const deletePocketItem = async (tripId: string, itemId: string): Promise<void> => {
  if (!tripId || !itemId) return;
  return queueWrite(async () => {
    try {
      const itemRef = doc(db, 'trips', tripId, 'pocketItems', String(itemId));
      await deleteDoc(itemRef);
    } catch (err) {
      console.error("Failed to delete pocket item from subcollection:", err);
      throw err;
    }
  });
};

/**
 * Saves a single journal item into subcollection (prevents 1MB root doc limit for photos)
 */
export const saveJournalItem = async (tripId: string, journal: Journal): Promise<void> => {
  if (!tripId || !journal || !journal.id) return;
  return queueWrite(async () => {
    try {
      if (Array.isArray(journal.images) && journal.images.length > 0) {
        const sanitizedImages: string[] = [];
        for (const img of journal.images) {
          if (typeof img === 'string' && img.startsWith('data:image/') && img.length > 380000) {
            sanitizedImages.push(await compressBase64IfNeeded(img, 1200, 320000));
          } else {
            sanitizedImages.push(img);
          }
        }
        journal = { ...journal, images: sanitizedImages };
      }

      // Schema V2 compliance & image reference normalization
      journal = {
        ...journal,
        schemaVersion: CURRENT_SCHEMA_VERSION,
        imageReferences: normalizeImagesList(journal.images, (journal as any).image, journal.photos),
      };

      let cleaned = cleanData(journal);

      const payloadSize = JSON.stringify(cleaned).length;
      if (payloadSize > 880000 && Array.isArray(cleaned.images)) {
        cleaned.images = await Promise.all(
          cleaned.images.map((img: string) => compressBase64IfNeeded(img, 1000, 200000))
        );
      }

      const itemRef = doc(db, 'trips', tripId, 'journals', String(journal.id));
      
      try {
        await setDoc(itemRef, cleaned);
      } catch (setErr: any) {
        if (setErr?.message?.includes('size') || setErr?.message?.includes('1,048,576') || setErr?.code === 'resource-exhausted') {
          console.warn("Firestore journal size exceeded, applying emergency compression...", setErr);
          if (Array.isArray(cleaned.images)) {
            cleaned.images = await Promise.all(
              cleaned.images.map((img: string) => compressBase64IfNeeded(img, 900, 140000))
            );
            await setDoc(itemRef, cleaned);
          } else {
            throw setErr;
          }
        } else {
          throw setErr;
        }
      }
    } catch (err) {
      console.error("Failed to save journal item to subcollection:", err);
      throw err;
    }
  });
};

/**
 * Deletes a single journal item from subcollection
 */
export const deleteJournalItem = async (tripId: string, journalId: number | string): Promise<void> => {
  if (!tripId || !journalId) return;
  return queueWrite(async () => {
    try {
      const itemRef = doc(db, 'trips', tripId, 'journals', String(journalId));
      await deleteDoc(itemRef);
    } catch (err) {
      console.error("Failed to delete journal item from subcollection:", err);
      throw err;
    }
  });
};

/**
 * Subscribes to real-time updates for a specific trip.
 * Automatically synchronizes subcollections `scheduleItems`, `pocketItems`, and `journals` to avoid 1MB document limit.
 */
export const subscribeToTrip = (tripId: string, onUpdate: (data: any) => void) => {
  try {
    const tripRef = doc(db, 'trips', tripId);
    const scheduleColRef = collection(db, 'trips', tripId, 'scheduleItems');
    const pocketColRef = collection(db, 'trips', tripId, 'pocketItems');
    const journalColRef = collection(db, 'trips', tripId, 'journals');
    
    let currentTripData: any = null;
    let subcollectionScheduleItems: ScheduleItem[] = [];
    let subcollectionPocketItems: PocketItem[] = [];
    let subcollectionJournals: Journal[] = [];

    // Track initial resolution of all subscriptions to prevent emitting premature empty arrays
    let hasTripDoc = false;
    let hasScheduleCol = false;
    let hasPocketCol = false;
    let hasJournalCol = false;
    let initialSyncComplete = false;
    let initialSyncTimer: ReturnType<typeof setTimeout> | null = null;

    const notifyCombined = () => {
      if (!currentTripData) return;

      // 1. Merge schedule items: Subcollection takes precedence over legacy root array
      const scheduleMap = new Map<string, ScheduleItem>();
      if (Array.isArray(currentTripData.scheduleItems)) {
        for (const item of currentTripData.scheduleItems) {
          if (item && item.id) {
            scheduleMap.set(String(item.id), item);
          }
        }
      }
      for (const item of subcollectionScheduleItems) {
        if (item && item.id) {
          scheduleMap.set(String(item.id), item);
        }
      }
      const rawSchedule = Array.from(scheduleMap.values());
      const finalSchedule = sortScheduleItems(rawSchedule, currentTripData.scheduleOrder);

      // 2. Merge pocket items: Subcollection takes precedence, defensively preserving fields
      const pocketMap = new Map<string, PocketItem>();
      if (Array.isArray(currentTripData.pocketItems)) {
        for (const item of currentTripData.pocketItems) {
          if (item && item.id) {
            pocketMap.set(String(item.id), item);
          }
        }
      }
      for (const item of subcollectionPocketItems) {
        if (item && item.id) {
          const prevItem = pocketMap.get(String(item.id));
          if (prevItem) {
            pocketMap.set(String(item.id), {
              ...prevItem,
              ...item,
              notes: item.notes || (item as any).note || prevItem.notes || (prevItem as any).note || '',
              images: (Array.isArray(item.images) && item.images.length > 0) ? item.images : (prevItem.images || []),
              location: item.location || (item as any).address || prevItem.location || (prevItem as any).address || '',
              url: item.url || (item as any).googleMapUrl || (item as any).link || prevItem.url || (prevItem as any).googleMapUrl || '',
              priceRange: item.priceRange || (item as any).price || prevItem.priceRange || (prevItem as any).price || '',
            });
          } else {
            pocketMap.set(String(item.id), item);
          }
        }
      }
      const finalPocket = Array.from(pocketMap.values());
      finalPocket.sort((a, b) => (b.createdAt || 0) - (a.createdAt || 0));

      // 3. Merge journals: Subcollection takes precedence
      const journalMap = new Map<string, Journal>();
      if (Array.isArray(currentTripData.journals)) {
        for (const item of currentTripData.journals) {
          if (item && item.id) {
            journalMap.set(String(item.id), item);
          }
        }
      }
      for (const item of subcollectionJournals) {
        if (item && item.id) {
          journalMap.set(String(item.id), item);
        }
      }
      const finalJournals = Array.from(journalMap.values());
      finalJournals.sort((a, b) => (b.date || '').localeCompare(a.date || ''));

      const combined: any = {
        ...currentTripData,
      };

      // Only attach scheduleItems if subcollection has resolved OR legacy items exist
      if (hasScheduleCol || (Array.isArray(currentTripData.scheduleItems) && currentTripData.scheduleItems.length > 0)) {
        combined.scheduleItems = finalSchedule;
      }

      // Only attach pocketItems if subcollection has resolved OR legacy items exist, avoiding premature empty wipeouts
      if (hasPocketCol || (Array.isArray(currentTripData.pocketItems) && currentTripData.pocketItems.length > 0)) {
        combined.pocketItems = finalPocket;
      }

      // Only attach journals if subcollection has resolved OR legacy items exist
      if (hasJournalCol || (Array.isArray(currentTripData.journals) && currentTripData.journals.length > 0)) {
        combined.journals = finalJournals;
      }

      onUpdate(combined);
    };

    const tryInitialNotify = () => {
      if (initialSyncComplete) {
        notifyCombined();
        return;
      }
      // Check if all essential initial snapshots have arrived
      if (hasTripDoc && hasScheduleCol && hasPocketCol && hasJournalCol) {
        if (initialSyncTimer) {
          clearTimeout(initialSyncTimer);
          initialSyncTimer = null;
        }
        initialSyncComplete = true;
        notifyCombined();
      } else if (hasTripDoc) {
        // If trip doc is here, start safety timer so we never wait more than 350ms for subcollections
        if (!initialSyncTimer) {
          initialSyncTimer = setTimeout(() => {
            initialSyncComplete = true;
            initialSyncTimer = null;
            notifyCombined();
          }, 350);
        }
      }
    };

    // 1. Subscribe to main trip document
    const unsubTrip = onSnapshot(tripRef, (docSnap) => {
      if (docSnap.exists()) {
        hasTripDoc = true;
        currentTripData = docSnap.data();
        tryInitialNotify();
      }
    }, (error) => {
      console.error("Real-time sync error (trip doc):", error);
    });

    // 2. Subscribe to scheduleItems subcollection
    const unsubSchedule = onSnapshot(scheduleColRef, (colSnap) => {
      hasScheduleCol = true;
      subcollectionScheduleItems = colSnap.docs.map(d => d.data() as ScheduleItem);
      tryInitialNotify();
    }, (error) => {
      console.error("Real-time sync error (schedule subcollection):", error);
    });

    // 3. Subscribe to pocketItems subcollection
    const unsubPocket = onSnapshot(pocketColRef, (colSnap) => {
      hasPocketCol = true;
      subcollectionPocketItems = colSnap.docs.map(d => d.data() as PocketItem);
      tryInitialNotify();
    }, (error) => {
      console.error("Real-time sync error (pocket subcollection):", error);
    });

    // 4. Subscribe to journals subcollection
    const unsubJournal = onSnapshot(journalColRef, (colSnap) => {
      hasJournalCol = true;
      subcollectionJournals = colSnap.docs.map(d => d.data() as Journal);
      tryInitialNotify();
    }, (error) => {
      console.error("Real-time sync error (journal subcollection):", error);
    });

    return () => {
      if (initialSyncTimer) clearTimeout(initialSyncTimer);
      unsubTrip();
      unsubSchedule();
      unsubPocket();
      unsubJournal();
    };
  } catch (error) {
    console.error("Failed to subscribe to trip:", error);
    return () => {};
  }
};

/**
 * Adds an item to a specific collection or array field in the trip document atomically.
 */
export const addTripItem = async (tripId: string, collectionName: string, item: any): Promise<void> => {
  if (!tripId) return;
  return queueWrite(async () => {
    try {
      if (collectionName === 'scheduleItems') {
        await saveScheduleItem(tripId, item);
        return;
      }
      if (collectionName === 'pocketItems') {
        await savePocketItem(tripId, item);
        return;
      }
      if (collectionName === 'journals') {
        await saveJournalItem(tripId, item);
        return;
      }

      const tripRef = doc(db, 'trips', tripId);
      const cleanedItem = cleanData(item);
      await setDoc(tripRef, {
        [collectionName]: arrayUnion(cleanedItem)
      }, { merge: true });
    } catch (error) {
      console.error(`Failed to add item to ${collectionName}:`, error);
      throw new Error("更新資料失敗");
    }
  });
};

/**
 * Ultra-lightweight schedule reorder persistence.
 * Only updates the `order` field of items on the modified day,
 * and updates the root trip document `scheduleOrder` array.
 * This takes <1KB payload and 1 atomic commit, completely preventing write-stream exhaustion.
 */
export const reorderScheduleItems = async (
  tripId: string,
  updatedItems: { id: string | number; order: number }[],
  fullScheduleOrderIds: string[]
): Promise<void> => {
  if (!tripId) return;
  return queueWrite(async () => {
    try {
      const batch = writeBatch(db);

      for (const item of updatedItems) {
        if (item && item.id) {
          const itemRef = doc(db, 'trips', tripId, 'scheduleItems', String(item.id));
          batch.update(itemRef, { order: item.order });
        }
      }

      const tripRef = doc(db, 'trips', tripId);
      batch.set(tripRef, { scheduleOrder: fullScheduleOrderIds }, { merge: true });

      await batch.commit();
    } catch (err) {
      console.error("Failed to persist reordered schedule items:", err);
    }
  });
};

/**
 * Coordinated update for tripDays and scheduleItems.
 * Performs a single atomic batch diff update for subcollection scheduleItems and updates
 * tripDays/scheduleOrder in the root doc.
 * Never writes the heavy scheduleItems array into root doc, preventing write-stream exhaustion.
 */
export const updateTripDaysAndSchedule = async (
  tripId: string, 
  tripDays: any[], 
  scheduleItems: ScheduleItem[]
): Promise<void> => {
  if (!tripId) return;
  return queueWrite(async () => {
    try {
      const orderIds = scheduleItems.map(i => String(i.id));
      const newIds = new Set(orderIds);
      const scheduleColRef = collection(db, 'trips', tripId, 'scheduleItems');
      const existingSnap = await getDocs(scheduleColRef);
      const existingMap = new Map<string, any>();
      for (const d of existingSnap.docs) {
        existingMap.set(d.id, d.data());
      }

      const batch = writeBatch(db);
      let batchCount = 0;

      // 1. Delete items no longer in scheduleItems
      for (const existingDoc of existingSnap.docs) {
        if (!newIds.has(existingDoc.id)) {
          batch.delete(existingDoc.ref);
          batchCount++;
        }
      }

      // 2. Only write new items or update changed properties (e.g. date, order)
      for (let idx = 0; idx < scheduleItems.length; idx++) {
        const item = scheduleItems[idx];
        if (!item || !item.id) continue;
        const itemId = String(item.id);
        const itemRef = doc(db, 'trips', tripId, 'scheduleItems', itemId);
        const existingData = existingMap.get(itemId);
        const targetOrder = item.order !== undefined ? item.order : idx;

        if (!existingData) {
          batch.set(itemRef, cleanData({ ...item, order: targetOrder }));
          batchCount++;
        } else {
          const updates: Record<string, any> = {};
          if (existingData.date !== item.date) updates.date = item.date;
          if (existingData.order !== targetOrder) updates.order = targetOrder;
          if (existingData.time !== item.time) updates.time = item.time;
          if (existingData.title !== item.title) updates.title = item.title;

          if (Object.keys(updates).length > 0) {
            batch.update(itemRef, updates);
            batchCount++;
          }
        }
      }

      // 3. Update root document with tripDays and scheduleOrder (NEVER bloated scheduleItems)
      const tripRef = doc(db, 'trips', tripId);
      batch.set(tripRef, { 
        tripDays: cleanData(tripDays), 
        scheduleOrder: orderIds 
      }, { merge: true });
      batchCount++;

      if (batchCount > 0) {
        await batch.commit();
      }
    } catch (err) {
      console.error("Failed to update trip days and schedule:", err);
      throw err;
    }
  });
};

/**
 * Atomically updates a day's date, location, and fruit, while synchronizing all schedule items
 * belonging to that day to the new date.
 * Committed in a single atomic batch so no items or day cards are ever lost or desynced.
 */
export const updateTripDayDateAndDetails = async (
  tripId: string,
  oldDate: string,
  newDate: string,
  newLocation: string,
  newFruit: string,
  allTripDays: TripDay[],
  allScheduleItems: ScheduleItem[]
): Promise<void> => {
  if (!tripId) return;
  return queueWrite(async () => {
    try {
      const batch = writeBatch(db);

      // 1. Update tripDays in memory and sort chronologically
      const updatedDays = allTripDays.map(d => 
        d.date === oldDate ? { ...d, date: newDate, location: newLocation, fruit: newFruit } : d
      ).sort((a, b) => a.date.localeCompare(b.date));

      // 2. Identify all items on this day that need their date updated
      const updatedSchedule = allScheduleItems.map(item => 
        item.date === oldDate ? { ...item, date: newDate } : item
      );

      // 3. Atomically update affected subcollection items (ONLY the date field! No heavy re-uploads)
      if (oldDate !== newDate) {
        const affectedItems = allScheduleItems.filter(item => item.date === oldDate);
        for (const item of affectedItems) {
          if (item && item.id) {
            const itemRef = doc(db, 'trips', tripId, 'scheduleItems', String(item.id));
            batch.update(itemRef, { date: newDate });
          }
        }
      }

      // 4. Update the root trip document with new tripDays and scheduleOrder (NEVER bloated scheduleItems)
      const tripRef = doc(db, 'trips', tripId);
      batch.set(tripRef, {
        tripDays: cleanData(updatedDays),
        scheduleOrder: updatedSchedule.map(i => String(i.id))
      }, { merge: true });

      // 5. Commit atomic batch in a single request
      await batch.commit();
    } catch (err) {
      console.error("Failed to atomically update trip day date and details:", err);
      throw err;
    }
  });
};

/**
 * Updates a specific field or replaces a full list in the trip document with ultra-fast writeBatch.
 */
export const updateTripField = async (tripId: string, field: string, value: any): Promise<void> => {
  if (!tripId) return;
  return queueWrite(async () => {
    try {
      // If updating scheduleItems, route through coordinated updateTripDaysAndSchedule logic
      if (field === 'scheduleItems' && Array.isArray(value)) {
        const scheduleColRef = collection(db, 'trips', tripId, 'scheduleItems');
        const existingSnap = await getDocs(scheduleColRef);
        const existingMap = new Map<string, any>();
        for (const d of existingSnap.docs) {
          existingMap.set(d.id, d.data());
        }
        const newIds = new Set(value.map(s => String(s.id)));

        const batch = writeBatch(db);
        let batchCount = 0;

        // 1. Delete items no longer in list
        for (const existingDoc of existingSnap.docs) {
          if (!newIds.has(existingDoc.id)) {
            batch.delete(existingDoc.ref);
            batchCount++;
          }
        }

        // 2. Only set new items or update changed properties (e.g. date, order)
        for (let idx = 0; idx < value.length; idx++) {
          const item = value[idx];
          if (!item || !item.id) continue;
          const itemId = String(item.id);
          const itemRef = doc(db, 'trips', tripId, 'scheduleItems', itemId);
          const existingData = existingMap.get(itemId);
          const targetOrder = item.order !== undefined ? item.order : idx;

          if (!existingData) {
            const itemWithOrder = {
              ...item,
              order: targetOrder
            };
            batch.set(itemRef, cleanData(itemWithOrder));
            batchCount++;
          } else {
            const updates: Record<string, any> = {};
            if (existingData.date !== item.date) updates.date = item.date;
            if (existingData.order !== targetOrder) updates.order = targetOrder;
            if (existingData.time !== item.time) updates.time = item.time;
            if (existingData.title !== item.title) updates.title = item.title;

            if (Object.keys(updates).length > 0) {
              batch.update(itemRef, updates);
              batchCount++;
            }
          }
        }

        const tripRef = doc(db, 'trips', tripId);
        const orderIds = value.map(i => String(i.id));
        batch.set(tripRef, { 
          scheduleItems: [],
          scheduleOrder: orderIds 
        }, { merge: true });
        batchCount++;

        if (batchCount > 0) {
          await batch.commit();
        }
        return;
      }

      // If updating pocketItems, store them in the subcollection using atomic writeBatch
      if (field === 'pocketItems' && Array.isArray(value)) {
        const pocketColRef = collection(db, 'trips', tripId, 'pocketItems');
        const existingSnap = await getDocs(pocketColRef);
        const newIds = new Set(value.map(p => String(p.id)));

        const batch = writeBatch(db);

        for (const existingDoc of existingSnap.docs) {
          if (!newIds.has(existingDoc.id)) {
            batch.delete(existingDoc.ref);
          }
        }

        for (const item of value) {
          if (item && item.id) {
            const itemRef = doc(db, 'trips', tripId, 'pocketItems', String(item.id));
            batch.set(itemRef, cleanData(item));
          }
        }

        const tripRef = doc(db, 'trips', tripId);
        batch.set(tripRef, { pocketItems: [] }, { merge: true });

        await batch.commit();
        return;
      }

      // If updating journals, store them in the subcollection using atomic writeBatch
      if (field === 'journals' && Array.isArray(value)) {
        const journalColRef = collection(db, 'trips', tripId, 'journals');
        const existingSnap = await getDocs(journalColRef);
        const newIds = new Set(value.map(j => String(j.id)));

        const batch = writeBatch(db);

        for (const existingDoc of existingSnap.docs) {
          if (!newIds.has(existingDoc.id)) {
            batch.delete(existingDoc.ref);
          }
        }

        for (const item of value) {
          if (item && item.id) {
            const itemRef = doc(db, 'trips', tripId, 'journals', String(item.id));
            batch.set(itemRef, cleanData(item));
          }
        }

        const tripRef = doc(db, 'trips', tripId);
        batch.set(tripRef, { journals: [] }, { merge: true });

        await batch.commit();
        return;
      }

      const tripRef = doc(db, 'trips', tripId);
      const cleanedValue = cleanData(value);
      await setDoc(tripRef, {
        [field]: cleanedValue
      }, { merge: true });
    } catch (error) {
      console.error(`Failed to update field ${field}:`, error);
      throw new Error("同步資料失敗");
    }
  });
};
